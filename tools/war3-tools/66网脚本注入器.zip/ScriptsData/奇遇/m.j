call qiyuzy()
