call NGKCIV()
