call k_qcd( )
