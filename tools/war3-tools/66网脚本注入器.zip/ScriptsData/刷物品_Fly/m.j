call Fly_main()
