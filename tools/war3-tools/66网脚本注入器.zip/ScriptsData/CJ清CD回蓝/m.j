call ljzc()
