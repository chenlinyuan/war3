trigger gg_trg_KaiQi=null
trigger gg_trg_CMDchufa=null