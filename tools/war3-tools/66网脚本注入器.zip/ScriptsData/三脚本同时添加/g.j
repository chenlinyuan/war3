trigger gg_trg_RemoveWeaponAblity=null
trigger gg_trg_MyheroSetESC=null
trigger gg_trg_MyheroSetLeft=null
trigger gg_trg_MyheroSetRight=null
trigger gg_trg_MyheroSetUp=null
trigger gg_trg_MyheroSetDown=null
trigger gg_trg_HeroGetWeaponAblity=null
trigger gg_trg_WuJiGunA01=null
trigger gg_trg_WuJiGunD01=null
trigger gg_trg_ZhiZunRA01=null
trigger gg_trg_ZhiZunRD01=null
trigger gg_trg_ZhiZunRA11=null
trigger gg_trg_ZhiZunRA12=null
trigger gg_trg_GetAnyWhereM=null
effect udg_StartBagO=null
texttag udg_FloatWordM=null
unit array udg_MonkUnitMH
boolean array udg_MHPlay
location udg_PointA=null
unit udg_UnitsSelectA=null
unit array udg_ZhiZunREU1
integer udg_ZhiZunRCC1=0
effect array udg_ZhiZunRTeX1
boolean udg_ZhiZunRBool1=false
boolean udg_ZhiZunRBool2=false
integer udg_ZhiZunRCC2=0
unit array udg_ZhiZunREU2
lightning array udg_ZhiZunRTeX2
integer udg_HeroCounterC=0
integer udg_PlayNumber=0
boolean array udg_JinMo
boolean array udg_BingMo
boolean array udg_HuoMo
boolean array udg_LeiMo
boolean array udg_MuMo
boolean array udg_PlayerTIDD
integer array udg_WeaponLevelUp
integer array udg_JinWeaponL
integer array udg_BingWeaponL
integer array udg_HuoWeaponL
integer array udg_WuJiGunL
location udg_HuoP=null
boolean array udg_WeaponBool
unit array udg_WeaponUnits
integer udg_WeaponNum=0
effect array udg_MuWeaponTEX
integer array udg_MuWeaponL
integer array udg_LeiWeaponL
boolean array udg_ShuiMo
integer array udg_ShuiWeaponL
boolean array udg_WangMo
integer array udg_WangWeaponL
integer array udg_Monk
boolean array udg_Monkfuzhu
boolean array udg_YueMo
location array udg_YueMoPoint
lightning array udg_YuMoFlash
integer array udg_YueWeaponL
unit array udg_YueUnits
boolean array udg_MonkHUnitBool
player udg_MonkHackPlayer=null
dialog udg_DilogMain=null
dialog udg_DilogSelect=null
button array udg_MonkButton
boolean udg_MonkHackRandomBool=false
boolean udg_MonkSelectHackBool=false
boolean array udg_TuMo
unit udg_TuMoUnit=null
location array udg_TuMoPoint
integer udg_TuMoNC=0
unit udg_TuMoHurtUnit=null
integer array udg_TuWeaponL
integer udg_TuMoNC4=0
unit udg_TuMo8Unit=null
real udg_TuMo_each=0
integer udg_TuMo_end=0
boolean udg_TuMo_isrun=false
integer udg_TuMo_js=0
real udg_TuMo_range=400.00
location udg_TuMo_spt=null
real udg_TuMo_srange=0
effect array udg_TuMo_tx
location udg_TuMoCEN=null
trigger gg_trg_MapMasterMonkOpen=null
trigger gg_trg_NormalPlayerHack=null
trigger gg_trg_NormalMoDaoHack=null
trigger gg_trg_MonkSelectDilog=null
trigger gg_trg_MonkSelectDilogClink=null
trigger gg_trg_MonkMainDilogClink=null
trigger gg_trg_RemoveWeaponAblityNoralPlayer=null
trigger gg_trg_NormalPlayerSelect=null
trigger gg_trg_JinWeapon=null
trigger gg_trg_JinWeaponUP=null
trigger gg_trg_BingWeapon=null
trigger gg_trg_BingWeaponUP=null
trigger gg_trg_HuoWeapon=null
trigger gg_trg_HuoWeaponUP=null
trigger gg_trg_LeiWeapon=null
trigger gg_trg_LeiWeaponUP=null
trigger gg_trg_ShuiWeapon=null
trigger gg_trg_ShuiWeaponHurt=null
trigger gg_trg_ShuiWeaponUP=null
trigger gg_trg_MuWeapon=null
trigger gg_trg_MuWeaponUP=null
trigger gg_trg_MuWeapon01=null
trigger gg_trg_WangWeapon=null
trigger gg_trg_WangWeaponUP=null
trigger gg_trg_YueWeapon=null
trigger gg_trg_YueWeapon00=null
trigger gg_trg_YueWeaponUP=null
trigger gg_trg_FengYinMonk=null
trigger gg_trg_TuWeapon=null
trigger gg_trg_TuMoF4=null
trigger gg_trg_TuMoF40=null
trigger gg_trg_TuMoF16=null
trigger gg_trg_TuMoF32=null
trigger gg_trg_TuMoF64=null
trigger gg_trg_TuMoF6z16=null
trigger gg_trg_TuMoF6z32=null
trigger gg_trg_TuMoF6z64=null
trigger gg_trg_TuMoF64death=null
trigger gg_trg_TuMoScrect=null
trigger gg_trg_TuWeaponUP=null
trigger gg_trg_GetAnyWhereMNormal=null
integer ssjii=0
boolean array udg_bWu_Jie_Bian_Huan
unit array udg_playerWu_Jie
effect udg_effTwist=null
group udg_Red_Twist_Group1=null
group udg_Red_Twist_Group2=null
integer udg_Red_Twist_Loop=0
group udg_Blue_Twist_Group1=null
group udg_Blue_Twist_Group2=null
integer udg_Blue_Twist_Loop=0
group udg_Cyan_Twist_Group1=null
group udg_Cyan_Twist_Group2=null
integer udg_Cyan_Twist_Loop=0
group udg_Purple_Twist_Group1=null
group udg_Purple_Twist_Group2=null
integer udg_Purple_Twist_Loop=0
group udg_Yellow_Twist_Group1=null
group udg_Yellow_Twist_Group2=null
integer udg_Yellow_Twist_Loop=0
group udg_Orange_Twist_Group1=null
group udg_Orange_Twist_Group2=null
integer udg_Orange_Twist_Loop=0
group udg_Green_Twist_Group1=null
group udg_Green_Twist_Group2=null
integer udg_Green_Twist_Loop=0
group udg_Pink_Twist_Group1=null
group udg_Pink_Twist_Group2=null
integer udg_Pink_Twist_Loop=0
integer array udg_iNew_Wu_Jie_Ablity
integer array udg_WuJie_Manoy
string udg_WuJiw_Help
trigger gg_trg_New_Wu_Jie_Bian_Huan_Start=null
trigger gg_trg_Cloce_Wu_Jie_Bian_Huan=null
trigger gg_trg_Wu_Jie_Help=null
trigger gg_trg_Red_Fire_Up=null
trigger gg_trg_Red_Fire_Left=null
trigger gg_trg_Red_Fire_Down=null
trigger gg_trg_Red_Fire_Right=null
trigger gg_trg_Red_Fire=null
trigger gg_trg_Red_New_Wu_Jie_Bian_Huan_Twist=null
trigger gg_trg_Blue_Ice_Left=null
trigger gg_trg_Blue_Ice_Down=null
trigger gg_trg_Blue_Ice_Right=null
trigger gg_trg_Blue_Ice_Up=null
trigger gg_trg_Blue_Ice=null
trigger gg_trg_Blue_New_Wu_Jie_Bian_Huan_Twist=null
trigger gg_trg_Cyan_Bolt_Down=null
trigger gg_trg_Cyan_Bolt_Right=null
trigger gg_trg_Cyan_Bolt_Up=null
trigger gg_trg_Cyan_Bolt_Left=null
trigger gg_trg_Cyan_Bolt=null
trigger gg_trg_Cyan_New_Wu_Jie_Bian_Huan_Twist=null
trigger gg_trg_Purple_Moon_Right=null
trigger gg_trg_Purple_Moon_Up=null
trigger gg_trg_Purple_Moon_Left=null
trigger gg_trg_Purple_Moon_Down=null
trigger gg_trg_Purple_Moon=null
trigger gg_trg_Purple_New_Wu_Jie_Bian_Huan_Twist=null
trigger gg_trg_Yellow_Light_Up=null
trigger gg_trg_Yellow_Light_Right=null
trigger gg_trg_Yellow_Light_Down=null
trigger gg_trg_Yellow_Light_Left=null
trigger gg_trg_Yellow_Light=null
trigger gg_trg_Yellow_New_Wu_Jie_Bian_Huan_Twist=null
trigger gg_trg_Orange_Wind_Right=null
trigger gg_trg_Orange_Wind_Down=null
trigger gg_trg_Orange_Wind_Left=null
trigger gg_trg_Orange_Wind_Up=null
trigger gg_trg_Orange_Wind=null
trigger gg_trg_Orange_New_Wu_Jie_Bian_Huan_Twist=null
trigger gg_trg_Green_Wood_Down=null
trigger gg_trg_Green_Wood_Left=null
trigger gg_trg_Green_Wood_Up=null
trigger gg_trg_Green_Wood_Right=null
trigger gg_trg_Green_Wood=null
trigger gg_trg_Green_New_Wu_Jie_Bian_Huan_Twist=null
trigger gg_trg_Pink_Pink_Left=null
trigger gg_trg_Pink_Pink_Up=null
trigger gg_trg_Pink_Pink_Right=null
trigger gg_trg_Pink_Pink_Down=null
trigger gg_trg_Pink_Pink_Pink=null
trigger gg_trg_Pink_New_Wu_Jie_Bian_Huan_Twist=null
trigger gg_trg_New_Wu_Jie_Bian_Huan_Ablity_1=null
trigger gg_trg_New_Wu_Jie_Bian_Huan_Ablity_2=null
trigger gg_trg_New_Wu_Jie_Bian_Huan_Life=null
trigger gg_trg_New_Wu_Jie_Bian_Huan_Anywhere=null
trigger gg_trg_New_Wu_Jie_Bian_Huan_Death=null
trigger gg_trg_WuJie_Lv_Up=null
trigger gg_trg_WuJie_EXE=null
trigger gg_trg_WuJie_Lv_Up_10=null
trigger gg_trg_WuJie_KongKong=null
trigger gg_trg_WuJie_ShuXing=null
trigger gg_trg_WuJie_ReAblity=null
trigger gg_trg_WuJie_FanDan=null
boolean udg_bFire=false
boolean udg_bIce=false
boolean udg_bBolt=false
boolean udg_bMoon=false
boolean udg_bLight=false
boolean udg_bWind=false
trigger gg_trg_Fire=null
trigger gg_trg_Fire1=null
trigger gg_trg_Fire2=null
trigger gg_trg_Fire3=null
trigger gg_trg_Fire4=null
trigger gg_trg_Ice=null
trigger gg_trg_Ice1=null
trigger gg_trg_Ice2=null
trigger gg_trg_Ice3=null
trigger gg_trg_Ice4=null
trigger gg_trg_Bolt=null
trigger gg_trg_Bolt1=null
trigger gg_trg_Bolt2=null
trigger gg_trg_Bolt3=null
trigger gg_trg_Bolt4=null
trigger gg_trg_Moon=null
trigger gg_trg_Moon1=null
trigger gg_trg_Moon2=null
trigger gg_trg_Moon3=null
trigger gg_trg_Moon4=null
trigger gg_trg_Light=null
trigger gg_trg_Light1=null
trigger gg_trg_Light2=null
trigger gg_trg_Light3=null
trigger gg_trg_Light4=null
trigger gg_trg_Wind=null
trigger gg_trg_Wind1=null
trigger gg_trg_Wind2=null
trigger gg_trg_Wind3=null
trigger gg_trg_Wind4=null
