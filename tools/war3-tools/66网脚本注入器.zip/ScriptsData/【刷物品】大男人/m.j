call InitTrig_BigMan()
