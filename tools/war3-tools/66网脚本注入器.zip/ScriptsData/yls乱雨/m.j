call yulaosan()
call yulaosanCG()
