call ExecuteFunc( "ZhuanSheng" )
